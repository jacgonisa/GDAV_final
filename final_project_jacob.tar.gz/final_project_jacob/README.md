#FINAL PROJECT#

###INITIAL SET UP

#I am cloning the original environment so I can modify mine to add some functionalities, such as 'parallel'
conda create --name jacob_gdav23 --clone gdav23

mamba install parallel

#SET UP ID

parallel echo {} ::: hightemp normaltemp > ids.txt

#Task1. Use the tool mOTUs for taxonomic profiling
mkdir 01metagenomics
mkdir 01metagenomics/results
mkdir 01metagenomics/log
##GO TO 01metagenomics/README.md

#Task2 
mkdir 02rna_seq
mkdir 02rna_seq/results
mkdir 02rna_seq/log

#Task3
mkdir 03variant_calling
mkdir 03variant_calling/results
mkdir 03variant_calling/log

#Task4
mkdir 04de_analysis
mkdir 04comparative/results
mkdir 04comparatice/log


#Task5
mkdir 05comparative
mkdir 05comparative/results
mkdir 05comparative/log

#Task6
mkdir 06phylogenetics
mkdir 06phylogenetics/results
mkdir 06phylogenetics/log










#motus merge -d 01metagenomics -o 01metagenomics/metagenomics-hotspring-joined.motus
